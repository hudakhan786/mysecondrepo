def main():
    #open a file named philosophers.txt
    outfile = 


    #write the names of three philosophers to the file
    #John Locke, David Hume and Edmund Burke



    #close the file


#call the main function
main()